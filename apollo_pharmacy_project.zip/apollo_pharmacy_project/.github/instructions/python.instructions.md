---
applyTo: "**/*.py"
---
Use Python 3.11+, type hints, clear function names, parameterized SQL, and focused exception handling. Never construct SQL by concatenating user input. Keep clinical decisions out of application logic and route them for pharmacist review.
