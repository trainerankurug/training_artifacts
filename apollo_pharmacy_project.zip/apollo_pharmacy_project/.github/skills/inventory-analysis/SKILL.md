# Inventory analysis playbook
1. Confirm the store identifier and medicine name when needed.
2. Search the inventory records and report the quantity, reorder level and expiry date.
3. For replenishment, compare quantity with reorder level and show the two-week demand estimate.
4. Clearly label every replenishment quantity as a suggestion requiring manager approval.
5. For near-expiry stock, list item, batch/SKU, quantity and expiry date; ask staff to follow the organization's quarantine/returns policy.
6. Do not advise dispensing, discounting or transferring stock without an approved policy and human authorization.
