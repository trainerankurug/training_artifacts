# Order support playbook
1. Ask for the order ID; do not request unnecessary personal or medical information.
2. Retrieve the order status from the approved order source.
3. Explain the current status in plain language and state when the record was checked if a timestamp is available.
4. Do not mark orders delivered, cancel orders, issue refunds or send messages without explicit authorization through an approved workflow.
5. If the order is awaiting prescription or pharmacist verification, direct the customer to the pharmacist/store team.
