# Apollo Pharmacy – Smart Store Operations (Training Project)

A small, demo-ready pharmacy operations project using fictional/sample data. It demonstrates inventory lookup, near-expiry monitoring, reorder suggestions, order tracking, and safe request routing.

> **Safety boundary:** This is an operational training prototype, not a clinical system. It must not diagnose, prescribe, recommend substitutions, calculate doses, or approve prescriptions. Route clinical questions and prescription decisions to a licensed pharmacist. Never use the sample data for real patient care.

## What is included
- FastAPI backend with REST endpoints.
- SQLite database created from CSV sample data on first run.
- Sample inventory, sales and order records.
- GitHub Copilot workspace guidance, role definitions and reusable task playbooks.
- A small MCP server exposing read-only pharmacy operations tools.
- Basic tests.

## Project structure
```
app/                  API and data access
 data/                Fictional CSV seed data
.github/agents/       Role definitions for coding assistant workflows
.github/instructions/ Repository-wide development rules
.github/skills/       Reusable operational task playbooks
mcp_server/           Read-only MCP tool server
 tests/                API tests
```

## Run locally
Requires Python 3.11+.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000/docs for the API.

The SQLite database is created at `pharmacy.db` in the project root using the CSV files in `data/`.

## Example API calls
```bash
curl http://127.0.0.1:8000/health
curl http://127.0.0.1:8000/inventory/search?q=paracetamol
curl http://127.0.0.1:8000/inventory/near-expiry?days=60
curl http://127.0.0.1:8000/inventory/reorder-suggestions
curl http://127.0.0.1:8000/orders/ORD1002
curl -X POST http://127.0.0.1:8000/requests/triage -H "Content-Type: application/json" -d '{"message":"Can I take two tablets for my fever?"}'
```

## Run tests
```bash
pytest -q
```

## Run the MCP server
```bash
python -m mcp_server.server
```
It uses stdio transport and exposes read-only tools for inventory search, near-expiry stock, reorder suggestions and order status. Configure the MCP client in your development environment to launch this command from the repository root.

## Suggested live demonstration
1. Search for a medicine and show available quantity and store location.
2. Retrieve medicines expiring within 60 days.
3. Generate reorder suggestions from current stock and average daily sales.
4. Track a sample order.
5. Submit a clinical question and show that it is routed to a pharmacist rather than answered.
6. Ask the coding assistant to add a new endpoint while following the repository guidance and tests.

All names, stock counts, prices, dates and orders are synthetic. Replace them only with approved, de-identified test data in a controlled environment.
