from datetime import date, timedelta
from pathlib import Path
import csv
import sqlite3
from typing import Optional

from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "pharmacy.db"
DATA_DIR = ROOT / "data"
app = FastAPI(title="Apollo Pharmacy Operations API", version="1.0.0")


def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with connect() as db:
        db.execute("""CREATE TABLE IF NOT EXISTS inventory (
            sku TEXT PRIMARY KEY, medicine_name TEXT NOT NULL, category TEXT,
            store_id TEXT NOT NULL, quantity INTEGER NOT NULL, reorder_level INTEGER NOT NULL,
            avg_daily_sales REAL NOT NULL, unit_price REAL NOT NULL, expiry_date TEXT NOT NULL)""")
        db.execute("""CREATE TABLE IF NOT EXISTS orders (
            order_id TEXT PRIMARY KEY, customer_ref TEXT NOT NULL, store_id TEXT NOT NULL,
            status TEXT NOT NULL, created_on TEXT NOT NULL, fulfillment_mode TEXT NOT NULL)""")
        if db.execute("SELECT COUNT(*) FROM inventory").fetchone()[0] == 0:
            with open(DATA_DIR / "inventory.csv", newline="", encoding="utf-8") as f:
                db.executemany("INSERT INTO inventory VALUES (?,?,?,?,?,?,?,?,?)", [tuple(r.values()) for r in csv.DictReader(f)])
        if db.execute("SELECT COUNT(*) FROM orders").fetchone()[0] == 0:
            with open(DATA_DIR / "orders.csv", newline="", encoding="utf-8") as f:
                db.executemany("INSERT INTO orders VALUES (?,?,?,?,?,?)", [tuple(r.values()) for r in csv.DictReader(f)])


@app.on_event("startup")
def startup():
    init_db()


@app.get("/health")
def health():
    return {"status": "ok", "service": "apollo-pharmacy-operations"}


@app.get("/inventory/search")
def search_inventory(q: str = Query(min_length=2), store_id: Optional[str] = None):
    sql = "SELECT * FROM inventory WHERE lower(medicine_name) LIKE ?"
    params = [f"%{q.lower()}%"]
    if store_id:
        sql += " AND store_id = ?"
        params.append(store_id)
    with connect() as db:
        rows = db.execute(sql + " ORDER BY medicine_name", params).fetchall()
    return {"count": len(rows), "items": [dict(r) for r in rows]}


@app.get("/inventory/near-expiry")
def near_expiry(days: int = Query(default=60, ge=1, le=365), store_id: Optional[str] = None):
    cutoff = (date.today() + timedelta(days=days)).isoformat()
    sql = "SELECT * FROM inventory WHERE expiry_date <= ? AND expiry_date >= ?"
    params = [cutoff, date.today().isoformat()]
    if store_id:
        sql += " AND store_id = ?"
        params.append(store_id)
    with connect() as db:
        rows = db.execute(sql + " ORDER BY expiry_date", params).fetchall()
    return {"days": days, "count": len(rows), "items": [dict(r) for r in rows]}


@app.get("/inventory/reorder-suggestions")
def reorder_suggestions():
    with connect() as db:
        rows = db.execute("SELECT * FROM inventory WHERE quantity <= reorder_level ORDER BY quantity").fetchall()
    suggestions = []
    for r in rows:
        target = max(r["reorder_level"] * 2, round(r["avg_daily_sales"] * 14))
        suggestions.append({**dict(r), "suggested_order_quantity": max(0, target - r["quantity"]),
                            "basis": "Two-week demand estimate or twice the reorder level; manager approval required"})
    return {"count": len(suggestions), "items": suggestions}


@app.get("/orders/{order_id}")
def order_status(order_id: str):
    with connect() as db:
        row = db.execute("SELECT * FROM orders WHERE order_id = ?", (order_id,)).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Order not found")
    return dict(row)


class RequestTriage(BaseModel):
    message: str = Field(min_length=3, max_length=1000)


@app.post("/requests/triage")
def triage_request(payload: RequestTriage):
    text = payload.message.lower()
    clinical_terms = ["dose", "dosage", "tablet", "take", "side effect", "interaction", "pregnan", "child", "prescription", "substitute", "replace medicine", "symptom", "fever", "pain"]
    if any(term in text for term in clinical_terms):
        return {"route": "licensed_pharmacist", "priority": "review_required",
                "response": "This request needs review by a qualified pharmacist. The system will not provide medical or dosage advice."}
    if any(term in text for term in ["stock", "available", "inventory", "medicine"]):
        return {"route": "inventory_support", "priority": "normal", "response": "Please use the inventory search with the medicine name and store."}
    if "order" in text or "delivery" in text:
        return {"route": "order_support", "priority": "normal", "response": "Please provide the order ID to check its status."}
    return {"route": "store_support", "priority": "normal", "response": "This request has been routed to store support for review."}
