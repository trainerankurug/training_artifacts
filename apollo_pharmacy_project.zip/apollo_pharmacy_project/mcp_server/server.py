"""Read-only MCP tools for the synthetic Apollo Pharmacy training project."""
from pathlib import Path
import sqlite3
from mcp.server.fastmcp import FastMCP

DB = Path(__file__).resolve().parents[1] / "pharmacy.db"
mcp = FastMCP("apollo-pharmacy-operations")


def query(sql, params=()):
    if not DB.exists():
        return {"error": "Database not initialized. Start the FastAPI app once first."}
    with sqlite3.connect(DB) as conn:
        conn.row_factory = sqlite3.Row
        return [dict(row) for row in conn.execute(sql, params).fetchall()]


@mcp.tool()
def search_medicine_inventory(medicine_name: str, store_id: str = "") -> dict:
    """Find synthetic stock records by medicine name and optional store ID."""
    if len(medicine_name) < 2 or len(medicine_name) > 100:
        return {"error": "Medicine search must be between 2 and 100 characters."}
    sql = "SELECT sku, medicine_name, store_id, quantity, reorder_level, expiry_date FROM inventory WHERE lower(medicine_name) LIKE ?"
    params = [f"%{medicine_name.lower()}%"]
    if store_id:
        sql += " AND store_id = ?"
        params.append(store_id)
    return {"items": query(sql, params)}


@mcp.tool()
def list_near_expiry_stock(days: int = 60) -> dict:
    """List stock expiring within the next number of days (1–365)."""
    from datetime import date, timedelta
    if days < 1 or days > 365:
        return {"error": "days must be between 1 and 365"}
    return {"items": query("SELECT sku, medicine_name, store_id, quantity, expiry_date FROM inventory WHERE expiry_date BETWEEN ? AND ? ORDER BY expiry_date", (date.today().isoformat(), (date.today() + timedelta(days=days)).isoformat()))}


@mcp.tool()
def get_order_status(order_id: str) -> dict:
    """Retrieve a synthetic order status using its order ID."""
    if len(order_id) > 30:
        return {"error": "Invalid order ID"}
    rows = query("SELECT order_id, store_id, status, created_on, fulfillment_mode FROM orders WHERE order_id = ?", (order_id,))
    return {"order": rows[0] if rows else None}


if __name__ == "__main__":
    mcp.run(transport="stdio")
