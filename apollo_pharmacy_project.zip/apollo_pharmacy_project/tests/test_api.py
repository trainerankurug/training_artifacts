from fastapi.testclient import TestClient
from app.main import app, init_db

init_db()
client = TestClient(app)


def test_health():
    assert client.get("/health").json()["status"] == "ok"


def test_inventory_search():
    result = client.get("/inventory/search?q=paracetamol")
    assert result.status_code == 200
    assert result.json()["count"] >= 1


def test_clinical_question_is_escalated():
    result = client.post("/requests/triage", json={"message": "Can I take two tablets for fever?"})
    assert result.json()["route"] == "licensed_pharmacist"
